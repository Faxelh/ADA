# Faxel

Lecteur de musique et de vidéos pour iPhone (SwiftUI), avec moteur de
téléchargement intégré (Python + yt-dlp).

- Bibliothèque comme Musique : playlists, artistes, albums, morceaux, vidéos, favoris, Coffre (Face ID).
- Fichiers ajoutés avec 3uTools / iTunes (Apps › Faxel › Documents) ou l'app Fichiers : affichés automatiquement.
- Lecteur vidéo : portrait / paysage, verrou de rotation, sous-titres .srt / .vtt et intégrés, vitesse, pistes audio, Image dans l'image, gestes.
- Téléchargement depuis YouTube, TikTok, Instagram, Facebook, X… (vidéo ou audio).

La construction se fait sur GitHub Actions (`.github/workflows/faxel.yml`) :
l'artefact **Faxel-iPhone** contient `Faxel.ipa`, à installer avec Sideloadly.
