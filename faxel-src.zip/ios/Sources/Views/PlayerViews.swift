import SwiftUI

/// Mini-lecteur posé au-dessus de la barre d'onglets.
struct MiniPlayer: View {
    @EnvironmentObject var player: AudioPlayer
    @ObservedObject private var library = MediaLibrary.shared
    let open: () -> Void

    var body: some View {
        if let track = player.current {
            VStack(spacing: 0) {
                HStack(spacing: 12) {
                    TrackArtwork(track: track, width: 42, height: 42, radius: 7)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(library.title(track))
                            .font(.system(size: 15, weight: .semibold))
                            .lineLimit(1)
                        Text(library.artist(track))
                            .font(.system(size: 12))
                            .foregroundColor(.secondary)
                            .lineLimit(1)
                    }
                    Spacer(minLength: 4)
                    Button {
                        player.toggle()
                    } label: {
                        Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                            .font(.system(size: 22))
                            .foregroundColor(.primary)
                            .frame(width: 40, height: 40)
                    }
                    .buttonStyle(.plain)
                    Button {
                        player.next()
                    } label: {
                        Image(systemName: "forward.fill")
                            .font(.system(size: 19))
                            .foregroundColor(.primary)
                            .frame(width: 36, height: 40)
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 8)
                ClockProgressLine(clock: player.clock)
            }
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(.regularMaterial)
                    .shadow(color: .black.opacity(0.15), radius: 10, y: 3)
            )
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .padding(.horizontal, 10)
            .padding(.bottom, 6)
            .contentShape(Rectangle())
            .onTapGesture(perform: open)
        }
    }

}

/// Lecteur plein écran.
struct NowPlayingView: View {
    @EnvironmentObject var player: AudioPlayer
    @EnvironmentObject var model: AppModel
    @ObservedObject private var library = MediaLibrary.shared
    @Environment(\.dismiss) private var dismiss
    @State private var showQueue = false
    @State private var showLyrics = false
    @State private var showEqualizer = false
    @State private var lyrics: String?
    @State private var lyricsFor = ""
    @State private var picking: Track?

    var body: some View {
        ZStack {
            background
            if let track = player.current {
                VStack(spacing: 0) {
                    Capsule()
                        .fill(Color.white.opacity(0.4))
                        .frame(width: 38, height: 5)
                        .padding(.top, 10)
                    HStack {
                        Button {
                            dismiss()
                        } label: {
                            Image(systemName: "chevron.down")
                                .font(.system(size: 18, weight: .semibold))
                                .frame(width: 40, height: 40)
                        }
                        Spacer()
                        Text(L("En cours de lecture"))
                            .font(.system(size: 13, weight: .semibold))
                            .opacity(0.8)
                        Spacer()
                        Menu {
                            TrackMenuItems(track: track, picking: $picking)
                        } label: {
                            Image(systemName: "ellipsis.circle")
                                .font(.system(size: 20, weight: .semibold))
                                .frame(width: 40, height: 40)
                        }
                    }
                    .foregroundColor(.white)
                    .padding(.horizontal, 16)

                    Spacer(minLength: 12)
                    if showLyrics {
                        ScrollView {
                            Text(lyrics ?? L("Aucune parole dans ce fichier."))
                                .font(.system(size: 22, weight: .bold))
                                .foregroundColor(.white.opacity(lyrics == nil ? 0.6 : 0.95))
                                .multilineTextAlignment(.leading)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.horizontal, 28)
                                .padding(.vertical, 10)
                        }
                        .frame(maxHeight: 340)
                    } else {
                        TrackArtwork(track: track, width: 300, height: 300, radius: 22)
                            .shadow(color: .black.opacity(0.35), radius: 24, y: 12)
                            .scaleEffect(player.isPlaying ? 1 : 0.88)
                            .animation(.spring(response: 0.45, dampingFraction: 0.7), value: player.isPlaying)
                        SpectrumBarsView(meter: player.meter)
                            .frame(width: 260, height: 36)
                            .padding(.top, 14)
                            .opacity(player.isPlaying ? 0.9 : 0.25)
                    }
                    Spacer(minLength: 12)

                    HStack(alignment: .center) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(library.title(track))
                                .font(.system(size: 21, weight: .bold))
                                .lineLimit(2)
                            Text([library.artist(track), library.album(track) ?? ""].filter { !$0.isEmpty }
                                    .joined(separator: " — "))
                                .font(.system(size: 16))
                                .opacity(0.7)
                                .lineLimit(1)
                        }
                        Spacer()
                        Button {
                            model.toggleFavorite(track)
                        } label: {
                            Image(systemName: model.isFavorite(track) ? "heart.fill" : "heart")
                                .font(.system(size: 24))
                                .foregroundColor(model.isFavorite(track) ? .brand : .white)
                        }
                    }
                    .foregroundColor(.white)
                    .padding(.horizontal, 28)

                    PlayerScrubber(clock: player.clock) { player.seek(to: $0) }
                    .padding(.horizontal, 28)
                    .padding(.top, 18)

                    HStack {
                        Button {
                            player.toggleShuffle()
                        } label: {
                            Image(systemName: "shuffle")
                                .font(.system(size: 20, weight: .semibold))
                                .foregroundColor(player.shuffle ? .brand : Color.white.opacity(0.8))
                        }
                        Spacer()
                        Button {
                            player.previous()
                        } label: {
                            Image(systemName: "backward.fill")
                                .font(.system(size: 30))
                        }
                        Spacer()
                        Button {
                            player.toggle()
                        } label: {
                            Image(systemName: player.isPlaying ? "pause.circle.fill" : "play.circle.fill")
                                .font(.system(size: 72))
                                .symbolRenderingMode(.hierarchical)
                        }
                        Spacer()
                        Button {
                            player.next()
                        } label: {
                            Image(systemName: "forward.fill")
                                .font(.system(size: 30))
                        }
                        Spacer()
                        Button {
                            player.cycleRepeat()
                        } label: {
                            Image(systemName: player.repeatMode == .one ? "repeat.1" : "repeat")
                                .font(.system(size: 20, weight: .semibold))
                                .foregroundColor(player.repeatMode == .off ? Color.white.opacity(0.8) : .brand)
                        }
                    }
                    .foregroundColor(.white)
                    .padding(.horizontal, 30)
                    .padding(.top, 10)

                    HStack {
                        Menu {
                            ForEach([0, 15, 30, 45, 60, 90], id: \.self) { minutes in
                                Button {
                                    player.setSleepTimer(minutes: minutes)
                                } label: {
                                    Text(minutes == 0 ? L("Désactivé") : L("{minutes} min", ["minutes": "\(minutes)"]))
                                }
                            }
                        } label: {
                            Image(systemName: player.sleepEnd == nil ? "moon.zzz" : "moon.zzz.fill")
                                .font(.system(size: 20))
                                .foregroundColor(player.sleepEnd == nil ? Color.white.opacity(0.8) : .brand)
                                .frame(width: 44, height: 44)
                        }
                        Spacer()
                        Menu {
                            ForEach(speeds, id: \.self) { value in
                                Button {
                                    player.setRate(value)
                                } label: {
                                    if value == player.rate {
                                        Label(speedText(value), systemImage: "checkmark")
                                    } else {
                                        Text(speedText(value))
                                    }
                                }
                            }
                        } label: {
                            Text(speedText(player.rate))
                                .font(.system(size: 15, weight: .bold))
                                .foregroundColor(player.rate == 1 ? Color.white.opacity(0.8) : .brand)
                                .frame(width: 48, height: 44)
                        }
                        Spacer()
                        Button {
                            withAnimation(.easeInOut(duration: 0.25)) { showLyrics.toggle() }
                            loadLyrics(track)
                        } label: {
                            Image(systemName: showLyrics ? "quote.bubble.fill" : "quote.bubble")
                                .font(.system(size: 20))
                                .foregroundColor(showLyrics ? .brand : Color.white.opacity(0.8))
                                .frame(width: 44, height: 44)
                        }
                        Spacer()
                        Button {
                            showEqualizer = true
                        } label: {
                            Image(systemName: player.eqEnabled ? "slider.horizontal.3" : "slider.horizontal.3")
                                .font(.system(size: 20))
                                .foregroundColor(player.eqEnabled ? .brand : Color.white.opacity(0.8))
                                .frame(width: 44, height: 44)
                        }
                        Spacer()
                        AirPlayButton(tint: .white)
                            .frame(width: 44, height: 44)
                        Spacer()
                        Button {
                            showQueue = true
                        } label: {
                            Image(systemName: "list.bullet")
                                .font(.system(size: 20, weight: .semibold))
                                .foregroundColor(.white.opacity(0.8))
                                .frame(width: 44, height: 44)
                        }
                    }
                    .padding(.horizontal, 28)
                    .padding(.top, 14)
                    .padding(.bottom, 24)
                }
                .onChange(of: track.path) { _ in
                    if showLyrics { loadLyrics(track) }
                }
                .onAppear { player.spectrumWanted = true }
                .onDisappear { player.spectrumWanted = false }
            } else {
                VStack(spacing: 16) {
                    EmptyState(icon: "music.note", title: L("Aucune lecture en cours"))
                    Button(L("Fermer")) { dismiss() }
                        .buttonStyle(PrimaryButtonStyle())
                        .padding(.horizontal, 80)
                }
                .foregroundColor(.white)
            }
        }
        .sheet(isPresented: $showQueue) {
            QueueSheet()
                .environmentObject(player)
                .environmentObject(model)
        }
        .sheet(item: $picking) { track in
            PlaylistPicker(track: track)
                .environmentObject(model)
        }
        .sheet(isPresented: $showEqualizer) {
            EqualizerView()
                .environmentObject(player)
        }
    }

    private var speeds: [Float] { [0.5, 0.75, 1, 1.25, 1.5, 2] }

    private func speedText(_ value: Float) -> String {
        let text = value == Float(Int(value)) ? "\(Int(value))" : String(format: "%g", value)
        return text.replacingOccurrences(of: ".", with: Lang.code == "fr" ? "," : ".") + "×"
    }

    private func loadLyrics(_ track: Track) {
        guard lyricsFor != track.path else { return }
        lyricsFor = track.path
        lyrics = nil
        MediaLibrary.lyrics(for: track) { text in
            if lyricsFor == track.path { lyrics = text }
        }
    }

    private var background: some View {
        let colors = artworkColors(player.current?.id ?? "faxel")
        let art = player.current.flatMap { library.artwork($0) }
        return ZStack {
            LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing)
            if let link = art, let url = URL(string: link) {
                Group {
                    LocalImage(url: url)
                }
                .blur(radius: 50)
                .opacity(0.85)
            }
            Color.black.opacity(0.35)
        }
        .ignoresSafeArea()
    }
}

/// File de lecture (« À suivre ») : toucher pour sauter, glisser pour réordonner ou retirer.
struct QueueSheet: View {
    @EnvironmentObject var player: AudioPlayer
    @ObservedObject private var library = MediaLibrary.shared
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                ForEach(Array(player.queue.enumerated()), id: \.offset) { offset, track in
                    HStack(spacing: 12) {
                        TrackArtwork(track: track, width: 44, height: 44, radius: 6)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(library.title(track))
                                .font(.system(size: 15, weight: offset == player.index ? .bold : .regular))
                                .foregroundColor(offset == player.index ? .brand : .primary)
                                .lineLimit(1)
                            Text(library.artist(track))
                                .font(.system(size: 12))
                                .foregroundColor(.secondary)
                                .lineLimit(1)
                        }
                        Spacer()
                        if offset == player.index {
                            PlayingBars(playing: player.isPlaying)
                        }
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        player.jump(to: offset)
                    }
                    .deleteDisabled(offset == player.index)
                }
                .onDelete { offsets in
                    player.removeFromQueue(at: offsets)
                }
                .onMove { source, destination in
                    player.moveInQueue(from: source, to: destination)
                }
            }
            .listStyle(.plain)
            .navigationTitle(L("À suivre"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    EditButton()
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(L("OK")) { dismiss() }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
}

/// Actions du lecteur plein écran (favori, playlist, partage).
struct TrackMenuItems: View {
    @EnvironmentObject var model: AppModel
    let track: Track
    @Binding var picking: Track?

    var body: some View {
        Button {
            model.toggleFavorite(track)
        } label: {
            if model.isFavorite(track) {
                Label(L("Retirer des favoris"), systemImage: "heart.slash")
            } else {
                Label(L("Favori"), systemImage: "heart")
            }
        }
        Button {
            picking = track
        } label: {
            Label(L("Ajouter à une playlist"), systemImage: "text.badge.plus")
        }
        if track.exists {
            ShareLink(item: track.fileURL) {
                Label(L("Partager"), systemImage: "square.and.arrow.up")
            }
        }
    }
}

/// Fine barre de progression du mini-lecteur.
struct ClockProgressLine: View {
    @ObservedObject var clock: PlaybackClock

    var body: some View {
        GeometryReader { geometry in
            Rectangle()
                .fill(Color.brand)
                .frame(width: geometry.size.width * progress, height: 2)
        }
        .frame(height: 2)
    }

    private var progress: CGFloat {
        guard clock.duration > 0 else { return 0 }
        return CGFloat(min(1, max(0, clock.currentTime / clock.duration)))
    }
}

/// Curseur de position du lecteur plein écran.
struct PlayerScrubber: View {
    @ObservedObject var clock: PlaybackClock
    let seek: (Double) -> Void
    @State private var scrubbing = false
    @State private var scrubValue: Double = 0

    var body: some View {
        VStack(spacing: 4) {
            Slider(value: Binding(
                get: { scrubbing ? scrubValue : clock.currentTime },
                set: { scrubValue = $0 }
            ), in: 0...max(clock.duration, 1), onEditingChanged: { editing in
                if editing {
                    scrubValue = clock.currentTime
                    scrubbing = true
                } else {
                    seek(scrubValue)
                    scrubbing = false
                }
            })
            .tint(.white)
            HStack {
                Text(Fmt.clock(scrubbing ? scrubValue : clock.currentTime))
                Spacer()
                Text("-" + Fmt.clock(max(0, clock.duration - (scrubbing ? scrubValue : clock.currentTime))))
            }
            .font(.system(size: 12, weight: .medium).monospacedDigit())
            .foregroundColor(.white.opacity(0.7))
        }
        .padding(.horizontal, 28)
        .padding(.top, 18)
    }
}
